<?php

namespace App\Livewire\Roles;

use Livewire\Component;

class RoleIndex extends Component
{
    public function render()
    {
        return view('livewire.roles.role-index');
    }
}
