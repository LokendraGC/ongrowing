<?php

namespace App\Livewire\Roles;

use Livewire\Component;

class RoleEdit extends Component
{
    public function render()
    {
        return view('livewire.roles.role-edit');
    }
}
